package com.jm.eleven;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElevenApplicationTests {

	@Test
	void contextLoads() {
	}

}
